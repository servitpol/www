<?php
if(!isset($_POST['upfile'])) {
?>
<form action="index.php?page=2" method="POST" enctype="multipart/form-data">
<div class="form-group">
<label for="fn">Select file for upload:</label>
<input type="hidden" name="MAX_FILE_SIZE" value="1024*1024*3"/>
<input type="file" name="fn" accept="image/*">
</div>	
<button type="submit" name="upfile">Send</button>
</form>




<?php
} else {
if($_FILES['fn']['error'] != 0) {
	echo '<h3 style="color:red;"> Ошибка'.$_FILES['fn']['error'].'</h3>';
	exit();
}

if(is_uploaded_file($_FILES['fn']['tmp_name'])){
		move_uploaded_file($_FILES['fn']['tmp_name'], "images/".$_FILES['fn']['name']);
		echo '<h3 style="color:green;"> File Uploaded Successfuly</h3>';
}

}

?>













