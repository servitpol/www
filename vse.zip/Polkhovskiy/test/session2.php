<?php
session_start();
	echo 'id='.session_id().'</br>';
	echo 'From file 2: '.$_SESSION['num'].'</br>';
?>
<a href="session1.php">Back</a>