﻿<?php
// подключаемся к БД
$link = mysqli_connect('localhost', 'servitsj_megai', 'k*V&DnMh', 'servitsj_megai') or die(mysqli_error()); // Соединение с базой данных 
$pass = $_POST['pass']; // Присваеваем другой переменной значение из поля с паролем
$pass2 = $_POST['pass2']; // Присваеваем другой переменной значение из поля с паролем

if (empty($_POST['login']))  // Условие - если поле логин пустое
{
echo "Поле логин не заполненно"; // Выводим сообщение об ошибке
}
if ($_POST['pass'] != $_POST['pass2']) {
	echo "Пароли не совпадают";
}        
else // Иначе если поля не пустые
{
$name = $_POST['name']; // Присваеваем переменной значение из поля с именем    
$login = $_POST['login']; // Присваеваем переменной значение из поля с логином             
$mail = $_POST['mail']; // Присваеваем другой переменной значение из поля с email
$query = "INSERT INTO `users` (nameuser, login, password, email) VALUES ('$name', '$login', '$pass', '$mail')"; // Создаем переменную с запросом к базе данных на отправку нового юзера
$result = mysqli_query($link, $query) or die(mysql_error()); // Отправляем переменную с запросом в базу данных 
echo "Регистрация прошла успешно!</br>"; // Сообщаем что все получилось
var_dump($result);
}

?>