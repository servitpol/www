<?php
$text = "dolor sit elit a qui dolor  officia deserunt dolor. sit elit mollit ani dolor. deserunt dolor sit elit mollit anidolor sit elit a qui officia.";
$zapros = "dolor ** sit ** elit";
$predloj = explode(". ", $text);
//var_dump($predloj);
$i = 0;
$i1 = 0;
$i2 = 0;
foreach($predloj as $sp){
	echo $sp.'</br>';
	$pos1 = strpos($sp, "dolor");
	//echo $pos1.'</br>';
	if($pos1 >= 0) {
		$i++;
		//continue;
	}
	$pos2 = strpos($sp, "sit");
	//echo $pos2.'</br>';
	if($pos2 >= 0) {
		$i1++;
		//continue;
	}
	$pos3 = strpos($sp, "elit");
	//echo $pos3.'</br>';
	if($pos3 >= 0) {
		$i2++;
		//continue;
	}
	echo $pos1.' '.$pos2.' '.$pos3.'</br>';
	if($pos1 < $pos2 && $pos2 < $pos3){
		//echo $sp.'</br>';
		
	}
}
/*
echo $i.'</br>';
echo $i1.'</br>';
echo $i2.'</br>';
*/
/*
$slova = explode(" ** ", $zapros);

foreach($predloj as $one) {
	$slovs = explode(" ", $one);
	$i = 0;
	foreach($slova as $slovo) {
	if (array_key_exists($slovo, $slovs)) {
    echo "Yahooo!";
	} else {
	echo ++$i.'</br>';
	}
}
 echo '</br>';
 echo '</br>';
}
*/

?>