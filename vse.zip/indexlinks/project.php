<?php include_once('header.php'); ?>
<?php 

session_start();
$login = ($_SESSION['login']);
if($login != NULL) {
	include_once('connect.php');
	
} else {
	header("Location: login.php"); exit;
}	
?>
<header class="col-lg-12">
<div class="col-lg-9">Сервис проверки индексации ссылок</div>
<div class="col-lg-3"><?php echo ' '.$login.' '; ?><span class="glyphicon glyphicon-user"></span><a href="?exits"> Выход </a></div>
</header>
<?php 
if (isset($_GET['exits'])) {
     session_destroy();
	 header("Location: login.php"); exit;
}
?>
<div class="content col-lg-12">
<table class="table col-lg-9" style="max-width: 800px; margin: 20px;">
  <thead>
	  <th>id</th>
      <th>Название проекта</th>
	  <th>Кол-во проверок</th>
	  <th>Дата создания проекта</th>
	  <th>Последняя проверка</th>
	  <th>Действия</th>
		
  </thead>
<tbody>
<?php
	echo '<tr>';
	$q=mysql_query("SELECT * FROM ".$db_table." where (login) IN ('".$login."')",$db) or die(mysql_error()); //в $a записывается запрос к бд
	//"SELECT (name) FROM ".$db_table." where (category) IN ('работа')"
	for ($c=0; $c<mysql_num_rows($q); $c++)
{
$f = mysql_fetch_assoc($q);
		echo '<td>'.++$c.'</td>';
		echo '<td><a href="cheks.php?project='.$f['project'].'">'.$f['project'].'</a></td>';
		echo '<td></td>';
		echo '<td>'.$f['date'].'</td>';
		echo '<td></td>';
		echo '<td></td>';
		echo '</tr>';
		$c--;
}
?>

</tbody>
</table>
<div class="sidebar col-lg-3">
<form action="project.php" method="post">
   <legend>Добавление нового проекта</legend>
   <input type="text" class="form-control" name="project" placeholder="Название проекта"> 
   <input type="submit" value="Добавить" class="btn btn-success">
</form>
<?php 
if(isset($_POST['project']) && ($_POST['project']) != NULL) {

	$projectname = basename($_POST['project']);
	$result = mysql_query("SELECT * FROM ".$db_table." WHERE `project` = '$projectname'",$db);
	$row = mysql_fetch_array($result);

	//Условие: если $row[0] пустое, т.е. его нет в БД, то происходит создание проекта. Если есть, то возвращает ответ 1
	if ($row[0] == ''){
	$result = mysql_query ("INSERT INTO ".$db_table." (login,project, date) VALUES ('$login','$projectname', NOW())");
    
			if ($result = 'true'){
				echo '<div class="project-status">'; 
				echo "Проект успешно создан!";
				header("Location: project.php");
			}else{
				echo '<div class="project-status">'; 
				echo "Ошибка!";
			}
		} else {
			echo "Такой проект уже есть!"; //ответ 1
		}
	echo '</div>'; 
}
?>
</div>
</div>
<?php include_once('footer.php'); ?>