
<?php

$uploaddir = 'files';
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
$file_array = file($uploadfile); // —читывание файла в массив $file_array

	
		$site = $file_array[0]; //проверяемый сайт
		
		$array = array();
        $array["user"] = 'smartinetseo@gmail.com';
        $array["password"] = 'Dfnheirf';
        $array["lr"] = "213"; //регион
		$array["request"] = "Для вас в нашем магазине можно купить диплом недорого, обращайтесь к нам."; //проверяемый запрос на индекс
        $array["url"] = $site;	
        $array["imp"] = 0;
		$content = file_get_contents("http://api.megaindex.ru/scan_yandex_page_index?".http_build_query($array));    //запрос индексации страницы в яндексе
        $json = json_decode($content);
		echo '<td>'.$site.'</td>';
		
        flush();
		ob_flush();
        if( !is_object($json) ){
            echo 'Не удалось разобрать данные';
            exit();
        }
        if ($json->status != 0) {
        echo $json->err_msg;
        exit;
        }
        $yap = ($json->data) ? '+' : '-';
		echo '<td>'.$yap.'</td>';
		//разделитель нового запроса
		
		$content = file_get_contents("http://api.megaindex.ru/scan_yandex_link_index?".http_build_query($array));    //запрос индексации ссылки в яндексе
        $json = json_decode($content);
        if( !is_object($json) ){
            echo 'Не удалось разобрать данные';
            exit();
        }
        if ($json->status != 0) {
        echo $json->err_msg;
        exit;
        }
        $yal = ($json->data) ? '+' : '-';
		echo '<td>'.$yal.'</td>';
		flush();
		ob_flush();
		//разделитель нового запроса
		
		$content = file_get_contents("http://api.megaindex.ru/scan_google_page_index?".http_build_query($array));    //запрос индексации страницы в гугле
		$json = json_decode($content);
		if( !is_object($json) ){
			echo 'Не удалось разобрать данные';
			exit();
		}
		if ($json->status != 0) {
			echo $json->err_msg;
			exit;
		}
		$gp = ($json->data) ? '+' : '-';
		echo '<td>'.$gp.'</td>';
		flush();
		ob_flush();
		//разделитель нового запроса
		
		$content = file_get_contents("http://api.megaindex.ru/scan_google_link_index?".http_build_query($array));    //запрос индексации ссылки в гугле
		$json = json_decode($content);
		if( !is_object($json) ){
			echo 'Не удалось разобрать данные';
			exit();
		}
		if ($json->status != 0) {
			echo $json->err_msg;
			exit;
		}
		$gl = ($json->data) ? '+' : '-';
		echo '<td>'.$gl.'</td>';
}
?>