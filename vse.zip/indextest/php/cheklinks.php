<?php

$uploaddir = 'files';
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);

$file_array = file($uploadfile); // —читывание файла в массив $file_array
$countarr = count($file_array);
echo $countarr;

?>