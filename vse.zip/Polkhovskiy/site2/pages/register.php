<?php 
	include_once('functions.php');
	if(!isset($_POST['reg']))
	{
?>
               <div class="col-lg-6 col-md-6 col-sm-6 col-xs-4" >
                    <form  method='post'>
                        <div class="form-group">
                           <!-- <div class="col-lg-6">-->
                                <label for='login'>Username:</label>
                                <input type='text' name='login' class='form-control' placeholder='Username' />
                          <!--  </div>-->
                        </div>


                        <div class="form-group">
                           <!-- <div class="col-lg-6">-->
                                <label for='pass1'>Password:</label>
                                <input type='password' name='pass1' class='form-control' size='10' placeholder='Password' />
                      <!--      </div>-->
                        </div>

                        <div class="form-group">
                           <!-- <div class="col-lg-6">-->
                                   <label for='pass2'>Confirm Password:</label>
                                <input type='password' name='pass2' class='form-control' size='10' placeholder='Confirm Password' />
                          <!--  </div>    -->
                        </div>

                        <div class="form-group">
                       <!--     <div class="col-lg-6">  -->
                                <label for='email'>Email:</label>
                                <input type='text' name='email' class='form-control' size='10' placeholder='E-mail' />
                      <!--      </div>-->
                        </div>
                         <input type='Submit' name='reg' value='Register' class='btn btn-primary' />
                    </form>
                </div>
    <?php
        }
        else
        {
		if(Register($_POST['login'], $_POST['pass1'], $_POST['email']))
			{
				echo '<h4 style ="color:green;">User Added Succesfuly!</h4>';
			}
	   }
    ?>