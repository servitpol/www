<?php
	$ar = array(11, 214, 14, 15432, 122, 1235, 999, 1234, 53);

	
	sort($ar); //сортировка массива по возрастанию
	rsort($ar); //сортировка массива по убыванию
	for ($i=0; $i < count($ar) ; $i++) { 
		echo $ar[$i].'<span style="color:red;">:</span>';
		
	}
	echo '</br>';

	$c = 0;
	while ($c < count($ar)) {
		echo $ar[$c].'*';
		$c++;
	}
	echo '</br>';

	$ar1 = array("yellow" => "banana", "red" => "chery", "green" => "kiwi"); //ассоциативный массив
	foreach ($ar1 as $a) {
		echo $a.',&nbsp;&nbsp;'; 
	}
	echo '</br>';
	foreach ($ar1 as $k => $v) {
		echo $k.':'.$v.'</br>'; 
	}

	
?>