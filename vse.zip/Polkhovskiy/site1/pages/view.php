<h2>View</h2>
<form action="index.php?page=4" method="post">
<p>Select file to read</p>
<select name="ftext" size="3"><!-- вертикальный размер окна -->
<option>Select file</option>
<?php
	
	$path = "images/";
	if($dir = opendir($path)){  //возвращает в dir bool если папка существует
		$filter = array('txt');
		$ar=array();
		while(($file = readdir($dir)) !== false) {  //возвращает тождественный false когда считало всю папку
			$fullname = $path.$file;//полный путь к файлу с папкой
			$pos = strrpos($fullname, '.'); //находит позицию точки с конца, аналог ф-ции strpos
			$ext = substr($fullname, $pos + 1); //записывает расширение файла
			$ext = strtolower($ext); //приводит к нижнему регистру если файл JPG
			if(in_array($ext, $filter) && !in_array($ext, $ar)){
				$ar[] = $fullname;
				echo '<option>'.$fullname.'</option>';
			}
		}
		closedir($dir); //закрыть папку, лучше всего закрывать, т.к. жрет много памяти


	}
	
?>
</select>
<input type="submit" name="subtext" value="OK" class="btn btn-primary">
</form>
