<div class="col-lg-12 admin-content">
	<div class="row">
		<form action='index.php?page=1' method='POST' class="form-inline">
		<select class="form-control" name="coid" required>
		<?php
			connect();
			$res = mysql_query('select * from countries');
			while($row = mysql_fetch_array($res, MYSQL_ASSOC)) {
				echo '<option value="'.$row['id'].'">'.$row['country'].'</option>';
			}
			mysql_free_result($res);
		?>
		</select>
		<input type='submit' name='getcountry' value='OK' class="btn btn-primary"/>
		<?php
		if(isset($_POST['getcountry'])){
			$coid = $_POST['coid'];
			$res1 = mysql_query('select * from cities where countryid='.$coid);
			echo '<select name="ciid" class="form-control">';
			while($rows = mysql_fetch_array($res1, MYSQL_NUM))
			{
				echo '<option value="'.$rows[0].'">'.$rows[1].'</option>';
			}
			echo '</select>';
			echo '<input type="submit" name="getcity" value="OK" class="btn btn-primary">';
			mysql_free_result($res1);
		}
		?>
		</form>
	</div>
</div>
<div class="col-lg-12">
<?php
if(isset($_POST['getcity'])){
	$ciid = $_POST['ciid'];
	$sel = 'select * from hotels where cityid='.$ciid;
	$res2 = mysql_query($sel);
	echo '<table class="table tale-striped">';
	echo '<tr><th>Hotel</th>';
	echo '<th>Stars</th>';
	echo '<th>Cost</th>';
	echo '<th>Info</th></tr>';
	
	while($row2 = mysql_fetch_array($res2, MYSQL_ASSOC)){
	echo '<tr>';
	echo '<td>'.$row2['hotel'].'</td>';
	echo '<td>'.$row2['stars'].'</td>';
	echo '<td>'.$row2['cost'].'</td>';
	echo '<td><a href="pages/hotelinfo.php?hid='.$row2['id'].'" target="_blank">Подробнее</a></td>';
	echo '</tr>';
		
		
	}
	echo '</table>';
}


?>
