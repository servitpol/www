<?php 
	function addNumbers($x, $y) { //x и y - это параметры ф-ции
		echo 'Sum is: '.($x + $y).'</br>';
	}

	function addNumbersColor($x, $y, $color) { //x и y - это параметры ф-ции
		echo 'Sum is:<span style="color:'.$color.'"> '.($x + $y).'</span></br>';
	}

	function getSum($x, $y) {
		return ($x + $y);
	}

?>