<?php

	$num1 = 10;
	$text = "hello";
	echo "Hello, world! </br>";
	echo '$num1 = '.$num1;
	echo '<h1>$num1 = <span style="color:green;">'.$num1.'</span></h1>';
	echo '</br>';

	$ar = array(10, 20, 50, 120); //обычный массив, индексный
	echo $ar[2].'</br>';
	$ar[2] = 1000;
	echo $ar[2].'</br>';

	print_r($ar); //print_r - вывод на экран значений массива
	echo '</br>';

	echo count($ar); //count - размер массива
	echo '</br>';

	$ar1 = array("yellow" => "banana", "red" => "chery", "green" => "kiwi"); //ассоциативный массив
	echo $ar1['green'];
	echo '</br>';
	$ar1['orange'] = 'mango';
	print_r($ar1);
?>