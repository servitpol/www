<?php
// В PHP 4.1.0 и более ранних версиях следует использовать $HTTP_POST_FILES
// вместо $_FILES.
if (isset($_POST['site'])) {
		
		$site = ($_POST['site']);
		$param = ($_POST['param']);
		$text = ($_POST['content']);
		$cena = ($_POST['cena']);
		$vremya = ($_POST['vremya']);
		getAllIndex ($site, $param, $text, $cena, $vremya);

}

function getAllIndex ($site, $param, $text, $cena, $vremya) {
		//первая часть ф-ции вызывает ф-ции обращения к api и рисует необрабатываемые данные этим скриптом
		$myarr = array();
		$myarr[0] = '</tr><td>'.$site.'</td>';
		$myarr[1] = '<td>'.$param.'</td>';
		$myarr[2] = '<td>'.$text.'</td>';
		$myarr[3] = '<td>'.$cena.'</td>';
		$myarr[4] = '<td>'.$vremya.'</td>';
		echo '<tr>';
		writeRow ($site, $param, $text, $cena, $vremya);
		$myarr[5] = getYAP($site, $text);
		$myarr[6] = getYAL($site, $text);
		$myarr[7] = getGP($site, $text);
		$myarr[8] = getGL($site, $text).'</tr>';
		//echo '</tr>';
		
		//вторая часть ф-ции записывает полученные данные в файл

		$fp = fopen('counter.txt', 'a+');
		foreach ($myarr as $output)
		{
		fwrite($fp, $output."\r\n");
		}
		
}

function writeRow ($site, $param, $text, $cena, $vremya) {
		$wert = ('<td>'.$site.'</td><td>'.$param.'</td><td>'.$text.'</td><td>'.$cena.'</td><td>'.$vremya.'</td>');
		echo $wert;
}

function getYAP($site, $text) {
	
		$array = array();
        $array["user"] = 'smartinetseo@gmail.com';
        $array["password"] = 'Dfnheirf';
        $array["lr"] = "213"; //регион
		$aaaaa = $text; //проверяемый запрос на индекс
        $array["url"] = $site;	
        $array["imp"] = 1;
		$content = @file_get_contents("http://api.megaindex.ru/scan_yandex_page_index?".http_build_query($array));    //запрос индексации страницы в яндексе
        $json = json_decode($content);
        if (!is_object($json)){
			$ryap = '<td>1E</td>';
            echo $ryap;
			return $ryap;
        }
        if ($json->status != 0) {
			$ryap = '<td>1A</td>';
            echo $ryap;
			return $ryap;
        }
		/*if ($json->data) {
			$ryap = "<td>1+</td>";
			echo $ryap;
			return $ryap;
		} else {
			$r = "<td>1-</td>";
			echo $ryap;
			return $ryap;
		}*/
			
        echo ($json->data) ? "<td>1+</td>" : "<td>1-</td>";
			/*$r = ($json->data).'1E';
			return $r;*/
		
}

function getYAL($site, $text) {
		
		$array = array();
        $array["user"] = 'smartinetseo@gmail.com';
        $array["password"] = 'Dfnheirf';
        $array["lr"] = "213"; //регион
		$array["request"] = $text; //проверяемый запрос на индекс
        $array["url"] = $site;	
        $array["imp"] = 1;
		$content = @file_get_contents("http://api.megaindex.ru/scan_yandex_link_index?".http_build_query($array));    //запрос индексации ссылки в яндексе
        $json = json_decode($content);
        if (!is_object($json)){
			$ryal = '<td>2E</td>';
            echo $ryal;
			return $ryal;
        }
        if ($json->status != 0) {
			$ryal = '<td>2A</td>';
            echo $ryal;
			return $ryal;
        }
		/*if ($json->data) {
			$ryap = "<td>1+</td>";
			echo $ryap;
			return $ryap;
		} else {
			$r = "<td>1-</td>";
			echo $ryap;
			return $ryap;
		}*/
			
        echo ($json->data) ? "<td>1+</td>" : "<td>1-</td>";
}		

function getGP($site, $text) {
		
		$array = array();
        $array["user"] = 'smartinetseo@gmail.com';
        $array["password"] = 'Dfnheirf';
        $array["lr"] = "213"; //регион
		$aaaaa = $text; //проверяемый запрос на индекс
        $array["url"] = $site;	
        $array["imp"] = 1;
		$content = @file_get_contents("http://api.megaindex.ru/scan_google_page_index?".http_build_query($array));    //запрос индексации страницы в гугле
		$json = json_decode($content);
        if (!is_object($json)){
			$rgp = '<td>3E</td>';
            echo $rgp;
			return $rgp;
        }
        if ($json->status != 0) {
			$rgp = '<td>3A</td>';
            echo $rgp;
			return $rgp;
        }
		/*if ($json->data) {
			$ryap = "<td>1+</td>";
			echo $ryap;
			return $ryap;
		} else {
			$r = "<td>1-</td>";
			echo $ryap;
			return $ryap;
		}*/
			
        echo ($json->data) ? "<td>1+</td>" : "<td>1-</td>";
}
		
function getGL($site, $text) {
		
		$array = array();
        $array["user"] = 'smartinetseo@gmail.com';
        $array["password"] = 'Dfnheirf';
        $array["lr"] = "213"; //регион
		$array["request"] = $text; //проверяемый запрос на индекс
        $array["url"] = $site;	
        $array["imp"] = 1;
		$content = @file_get_contents("http://api.megaindex.ru/scan_google_link_index?".http_build_query($array));    //запрос индексации ссылки в гугле
		$json = json_decode($content);
        if (!is_object($json)){
			$rgl = '<td>4E</td>';
            echo $rgl;
			return $rgl;
        }
        if ($json->status != 0) {
			$rgl = '<td>4A</td>';
            echo $rgl;
			return $rgl;
        }
		/*if ($json->data) {
			$ryap = "<td>1+</td>";
			echo $ryap;
			return $ryap;
		} else {
			$r = "<td>1-</td>";
			echo $ryap;
			return $ryap;
		}*/
			
        echo ($json->data) ? "<td>1+</td>" : "<td>1-</td>";
}

if(isset($_GET['projectchek'])) {
	$filename = ($_GET['file']);
	$projectname = ($_GET['projectchek']);
	echo $projectname.'</br>';

	
	$fpa = 'counter.txt';
	$site = file($fpa);
	$site = array_diff($site, array("\r\n")); //удаляем пустые строки
	$content = implode(";", $site);
	$countfile = ($_GET['count']);

	$db_host = "servitsj.beget.tech"; //соединение с apache
    $db_user = "servitsj_test"; // Логин БД
    $db_password = "622756"; // Пароль БД
   	$db_table = "cheks";
	
    $db = mysql_connect($db_host,$db_user,$db_password) OR DIE("Не могу создать соединение "); // Подключение к базе данных
	
    mysql_select_db("servitsj_test",$db); // Выборка базы
    mysql_query("SET NAMES 'utf8'",$db); // Установка кодировки соединения
	
	$result = mysql_query ("INSERT INTO ".$db_table." (project, filename, count, date, content) VALUES ('$projectname', '$filename', '$countfile', NOW(), '$content')");
	if ($result = 'true'){
				echo '<div class="project-status">'; 
				echo "Проект успешно создан!";
				header('Location: cheks.php?project='.$projectname.'');
			}else{
				echo '<div class="project-status">'; 
				echo "Ошибка!";
			}
}

if(isset($_GET['delete'])) {
	$iddelete = $_GET['delete'];
	$projectname = ($_GET['project']);
	
	$db_host = "servitsj.beget.tech"; //соединение с apache
    $db_user = "servitsj_test"; // Логин БД
    $db_password = "622756"; // Пароль БД
   	$db_table = "cheks";
	
    $db = mysql_connect($db_host,$db_user,$db_password) OR DIE("Не могу создать соединение "); // Подключение к базе данных
	
    mysql_select_db("servitsj_test",$db); // Выборка базы
    mysql_query("SET NAMES 'utf8'",$db); // Установка кодировки соединения
	
	$result = mysql_query ("DELETE FROM ".$db_table." WHERE `id` = $iddelete");
	//DELETE FROM ".$db_table." WHERE `id` = $iddelete
	if ($result = 'true'){
				header('Location: cheks.php?project='.$projectname.'');
			}else{
				echo '<div class="project-status">'; 
				echo "Ошибка!";
			}
}

if(isset($_GET['del'])) {
	$iddelete = $_GET['del'];
	$projectname = ($_GET['project']);
	
	$db_host = "servitsj.beget.tech"; //соединение с apache
    $db_user = "servitsj_test"; // Логин БД
    $db_password = "622756"; // Пароль БД
   	$db_table = "projects";
	
    $db = mysql_connect($db_host,$db_user,$db_password) OR DIE("Не могу создать соединение "); // Подключение к базе данных
	
    mysql_select_db("servitsj_test",$db); // Выборка базы
    mysql_query("SET NAMES 'utf8'",$db); // Установка кодировки соединения
	
	$result = mysql_query ("DELETE FROM ".$db_table." WHERE `id` = $iddelete");
	//DELETE FROM ".$db_table." WHERE `id` = $iddelete
	if ($result = 'true'){
				echo '<div class="project-status">'; 
				echo "Проект успешно создан!";
				header('Location: project.php');
			}else{
				echo '<div class="project-status">'; 
				echo "Ошибка!";
			}
}

?>
