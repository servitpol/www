<?php 
include_once('header.php'); 
include_once('test.php'); 
?>

<header class="col-lg-12">
<div class="col-lg-9">Сервис</div>
<div class="col-lg-3"><a href="?exits"> Выход </a></div>
</header>
<?php 
if (isset($_GET['exits'])) {
     session_destroy();
	 header("Location: index.php"); exit;
}
?>
<div class="content col-lg-6">
<table class="table">
  <thead>
	  <th>id</th>
      <th>Название проекта</th>
	  <th>Дата создания проекта</th>
  </thead>
<tbody>
<?php
	$projects = $advert->call('ProjectsGet', array('archive' => true));
		/*<Project>
          <Id>int</Id>
          <Archive>boolean</Archive>
          <Name>string</Name>
          <Www>string</Www>
          <Mode>Commercial or InternetShop or Satellite or SeoHammer or Manual</Mode>
          <Created>dateTime</Created>
          <Company>int</Company>
        </Project> */
$i = 1;
foreach($projects as $key => $project){
	foreach($project as $keys) {
		foreach($keys as $value) {
			if($value['Archive'] == 'false'){
			echo '<tr>'; 	
			echo '<td>'.$i.'</td>';	
			echo '<td><a href="links.php?project='.$value['Id'].'&name='.$value['Www'].'" target="_blank">'.$value['Www'].'</a></td>';
			echo '<td>'.$value['Created'].'</td>';
			echo '</tr>';
			$i++;
			}
		}
	}
}
?>
</tbody>
</table>
</div>
<div class="sidebar col-lg-6">
</div>
<?php include_once('footer.php'); ?>