jasmine.getFixtures().fixturesPath = 'base/spec/javascripts/fixtures/';
