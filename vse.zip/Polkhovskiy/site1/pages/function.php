<form action="index.php?page=1" method="post">
	<input type="text" placeholder="Login" name="login">
	<input type="password" placeholder="Password" name="pass">
	<input type="password" placeholder="Password" name="pass2">	
	<input type="mail" placeholder="e-mail" name="email">
	<input type="submit" value="Registration">
</form>
<?php 
	if(isset($_POST['login']) != NULL)
?>