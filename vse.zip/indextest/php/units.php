<?php
include_once 'megaindex.php';
$key = '4796663281ced5672d6d6f899147eb63'; // ��� API ���� !!!
$mi = new MegaIndex($key);

$array = $mi->get('user/units');
$units = $array['units'];
echo 'var units = '.$units.';';

$array = $mi->get('user/balance');
$balance = $array['balance'];
echo 'var balance = '.$balance.';';
?>