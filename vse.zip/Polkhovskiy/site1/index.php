<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/style.css" rel="stylesheet">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Тестовый сайт №1 по курсу PHP</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <header class="container-fluid">
		<div class="row">
			<div class="header-title">Тестовый сайт №1 по курсу PHP</div>
		</div>
    </header>
    <div class="wrapper">
    	<div class="container">
  	        <div class="row">
		        <div class="sidebar col-lg-3">
            <?php include_once ('pages/menu.php'); ?>
            <?php if(isset($_GET['page']) && ($_GET['page'] == 1)){include_once ('pages/function.php');} ?> 
            <?php if(isset($_GET['page']) && ($_GET['page'] == 2)){include_once ('pages/upload.php');} ?>
            <?php if(isset($_GET['page']) && ($_GET['page'] == 3)){include_once ('pages/gallery.php');} ?>
            <?php if(isset($_GET['page']) && ($_GET['page'] == 4)){include_once ('pages/view.php');} ?>
            </div>         
		        <div class="col-lg-9"> 
				<h1>Заголовок контента h1</h1>
				<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>
				<h2>Подзаголовок h2</h2>
				<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>
<?php
if(isset($_POST['subext'])){
  $ext = $_POST['ext'];
  $ar = glob($path.'*.'.$ext); //ф-ция которая выбирает все файлы по фильтру *. 
  echo '<div class="panel panel-primary">';
    foreach($ar as $a){
    echo '<a href="'.$a.'" target="_blank"><img src="'.$a.'" height="100px" border="0" alt="image"></a>';
    }
  echo '</div>';
}
?>    
<?php
if(isset($_POST['subtext'])){
  $ext = $_POST['ftext'];
  $text = file_get_contents($ext);
  echo '<div class="" style="max-width:800px;"><pre style="min-height: 300px;">';
  echo $text;
  echo '</pre></div>';
}
?> 
            </div> <!-- col-lg-9 -->
    		</div><!-- row -->
    	</div><!-- container-->
    </div><!-- wrapper-->

    <footer>
		<div class="container">
			<div class="footer-content">
				<p>footer и какой-то текст в нем</p>
			</div>
		</div>
    </footer>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>