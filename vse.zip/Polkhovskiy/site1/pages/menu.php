
<a href="index.php?page=1">Register</a>
<a href="index.php?page=2">Upload</a>
<a href="index.php?page=3">Gallery</a>
<a href="index.php?page=4">View</a>
