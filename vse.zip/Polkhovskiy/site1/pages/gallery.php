<h2>My Gallery</h2>
<form action="index.php?page=3" method="post">
<p>Select file type to display</p>
<select name="ext">
<option>Select file type</option>
<?php
	
	$path = "images/";
	if($dir = opendir($path)){  //возвращает в dir bool если папка существует
		$filter = array('jpg', 'png', 'jpeg', 'gif', 'bmp');
		$ar=array();
		while(($file = readdir($dir)) !== false) {  //возвращает тождественный false когда считало всю папку
			$fullname = $path.$file;//полный путь к файлу с папкой
			$pos = strrpos($fullname, '.'); //находит позицию точки с конца, аналог ф-ции strpos
			$ext = substr($fullname, $pos + 1); //записывает расширение файла
			$ext = strtolower($ext); //приводит к нижнему регистру если файл JPG
			if(in_array($ext, $filter) && !in_array($ext, $ar)){
				$ar[] = $ext;
				echo '<option>'.$ext.'</option>';
			}
		}
		closedir($dir); //закрыть папку, лучше всего закрывать, т.к. жрет много памяти


	}
	
?>
</select>
<input type="submit" name="subext" value="OK" class="btn btn-primary">
</form>
