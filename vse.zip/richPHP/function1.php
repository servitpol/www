<?php
/* функции вывода кол-ва вхождений на экран */ 
function getstrlenght($text) {
	$counttext = iconv_strlen($text,'UTF-8'); 					//кол-во символов с пробелами
	$arr = explode(" ", $text); 								//получаем массив слов с разделителем "пробел"
	echo 'Кол-во: '.(($counttext) - (count($arr)) + 1); 		//(кол-во символов) - (размер массива(кол-во пробелов)) + 1
}	

function getCountPV($text, $pv){
	$substr_count = substr_count($text, $pv); //получаем кол-во вхождений в текст всех словосочетаний
	echo $substr_count."&nbsp".$r."<br>"; 
}

/* функция разбирает полученные данные на массив 
и сортирует прямые вхождения от разбавленных */
	
function allVhodToArr ($pv)	{
	$result = array();
	$i = 0;
	$vhodArray = explode("\r", $pv); 			//разбиваем запросы на массив с разделителем "новая строка"
	foreach($vhodArray as $key) {		
		$a = substr($key, -5); 					//1.получаем *	
		$b = substr($a, 0, 1);    				//2.получаем *
		if($b !== '*') { 						//проверяем, если пятый символ с конца не *, значит это прямое вхождение
			$result[$i] = searchPV($key);
			echo $result[$i].'</br>';
		} else {
			$result[$i] = searchRV($key);
			echo $result[$i].'</br>';
		}
		$i++;
	}
var_dump($result);	
}


function searchPV($pv) {
	$howpv = substr($pv, -1); 					//в howpw будет цифра с кол-вом вхождений
	$vhod = substr($pv, 0, -4); 				//получаем чистый запрос
	return $vhod;
}

function searchRV($rv) {
	$howrv = substr($rv, -1); 					//в howpw будет цифра с кол-вом вхождений
	$vhoj = substr($rv, 0, -5); 				//получаем чистый запрос
	return $vhoj;
}

?>