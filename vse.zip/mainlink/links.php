<?php 
include_once('header.php'); 
include_once('test.php'); 
?>

<header class="col-lg-12">
<div class="col-lg-9">Сервис</div>
<div class="col-lg-3"><a href="?exits"> Выход </a></div>
</header>
<?php 
if (isset($_GET['exits'])) {
     session_destroy();
	 header("Location: index.php"); exit;
}
?>
<div class="content col-lg-6">
<?php if(isset($_GET['name'])) echo 'Ссылки сайта: '.$_GET['name']; ?>
<table class="table">
  <thead>
	  <th>id</th>
      <th>Название проекта</th>
      <th>ТИЦ</th>
      <th>Дата индексации</th>
	  <th>Дата создания проекта</th>
  </thead>
<tbody>
<?php
if(isset($_GET['project'])){
	
	$idpro	= $_GET['project'];
	$pro = $advert->call('PagesGetByProject', array('project' => $idpro));

	$i = 1;
	foreach($pro as $key => $project){
		foreach($project as $keys) {
			foreach($keys as $value) {
				
				$idpage = $value['Id'];
				$projects = $advert->call('LinksGet', array('page' => $idpage));
				/*
				<Link>
				  <Id>int</Id>
				  <Anchor>string</Anchor>
				  <Comment>string</Comment>
				  <Expired>dateTime</Expired>
				  <Created>dateTime</Created>
				  <LastProlong>dateTime</LastProlong>
				  <Project>int</Project>
				  <Page>int</Page>
				  <Cy>int</Cy>
				  <Pr>int</Pr>
				  <YaCa>boolean</YaCa>
				  <OldCy>int</OldCy>
				  <OldPr>int</OldPr>
				  <Cost>double</Cost>
				  <Currency>Usd or Rur</Currency>
				  <Site>int</Site>
				  <PageSite>long</PageSite>
				  <PageSiteUri>string</PageSiteUri>
				  <Type>int</Type>
				  <Status>Unknown or Placed or Unmoderated or Archived or Wait or Sleep</Status>
				  <Indexed>int</Indexed>
				  <IndexedDate>string</IndexedDate>
				  <PageLevel>int</PageLevel>
				</Link>
				*/
				foreach($projects as $key => $project){
					if($project) {
					foreach($project as $keys) {
						foreach($keys as $value) {
							
							echo '<tr>'; 	
							echo '<td>'.$i.'</td>';	
							echo '<td><a href="'.$value['PageSiteUri'].'" target="_blank">'.$value['PageSiteUri'].'</a></td>';
							echo '<td>'.$value['Cy'].'</td>';
							echo '<td>'.$value['IndexedDate'].'</td>';
							echo '<td>'.$value['Created'].'</td>';
							echo '</tr>';
							$i++;

						}
					}
					}
				}
				
			}
		}
	}
	
}


?>
</tbody>
</table>
</div>
<div class="sidebar col-lg-6">
</div>
<?php include_once('footer.php'); ?>