<?php 
if(isset($_GET['hid'])){
	$hid = $_GET['hid'];
	echo $hid;
}

?>