<?php include_once('header.php'); ?>
<?php 

session_start();
$login = ($_SESSION['login']);
if($login == NULL || $login != 'smartinetseo') {
	header("Location: richeditor.php");
} 
?>
<header class="col-lg-12">
<div class="col-lg-9">Сервис проверки индексации ссылок</div>
<div class="col-lg-3"><?php echo ' '.$login.' '; ?><a href="rich.php">Ричэдитор</a><span class="glyphicon glyphicon-user"></span><a href="?exits"> Выход </a></div>
</header>
<?php 
if (isset($_GET['exits'])) {
     session_destroy();
	 header("Location: index.php"); exit;
}
?>
<div class="content col-lg-12">
<table class="table col-lg-9" style="max-width: 800px; margin: 20px;">
  <thead>
	  <th>id</th>
      <th>Название проекта</th>
	  <th>Дата создания проекта</th>
	  <th>Действия</th>
		
  </thead>
<tbody>
<?php
	echo '<tr>';
	$q=mysql_query("SELECT * FROM ".$db_table." where (login) IN ('".$login."')",$db) or die(mysql_error()); //в $a записывается запрос к бд
	
	for ($c=0; $c<mysql_num_rows($q); $c++)
{
		$f = mysql_fetch_assoc($q);
		echo '<td>'.++$c.'</td>';
		echo '<td><a href="cheks.php?project='.$f['project'].'">'.$f['project'].'</a></td>';
		echo '<td>'.$f['date'].'</td>';
		echo '<td><a href="function.php?del='.$f['id'].'&project='.$f['project'].'" style="color:red;">Удалить</a></td>';
		echo '</tr>';
		$c--;
}
?>

</tbody>
</table>
<div class="sidebar col-lg-3">
<form action="project.php" method="post">
   <legend>Добавление нового проекта</legend>
   <input type="text" class="form-control" name="project" placeholder="Название проекта"> 
   <input type="submit" value="Добавить" class="btn btn-success">
</form>
<?php 
if(isset($_POST['project']) && ($_POST['project']) != NULL) {

	$projectname = basename($_POST['project']);
	$result = mysql_query("SELECT * FROM ".$db_table." WHERE `project` = '$projectname'",$db);
	$row = mysql_fetch_array($result);

	//Условие: если $row[0] пустое, т.е. его нет в БД, то происходит создание проекта. Если есть, то возвращает ответ 1
	if ($row[0] == ''){
	$result = mysql_query ("INSERT INTO ".$db_table." (login,project, date) VALUES ('$login','$projectname', NOW())");
    
			if ($result = 'true'){
				echo '<div class="project-status">'; 
				echo "Проект успешно создан!";
				header("Location: project.php");
			}else{
				echo '<div class="project-status">'; 
				echo "Ошибка!";
			}
		} else {
			echo "Такой проект уже есть!"; //ответ 1
		}
	echo '</div>'; 
}
?>
</div>
</div>
<div class="remember col-lg-12">
<ul>
<legend>Список того что нужно не забыть и сделать:</legend>
<ol>
<li>1. Majestic Trust Flow - это траст</li>
<li>2. Linkpad спамность - это спам</li>
<li>3. Проверить работу api, криво возвращает результаты</li>
<li>4. Ввести еще одну ошибку - конец ответа api по таймауту</li>
<li>5. В скриншотах есть скрины того как нужно формировать файл для загрузки</li>
</ol>

<legend>Общая концепция: </legend>
<ul>
<li>- реализовать возможность подгружать проекты через api из mainlink`a; </li>
<li>- проверка закупленных ссылок на траст, спам, агс, индексацию в пс; </li>
<li>- удаление их из сервиса и аналогичное удаление из mainlink`a.</li>
</ul>
</div>
<?php include_once('footer.php'); ?>