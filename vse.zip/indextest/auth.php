<?php
// подключаемся к БД
$link = mysqli_connect('localhost', 'servitsj_megai', 'k*V&DnMh', 'servitsj_megai') or die(mysqli_error()); // Соединение с базой данных 
if (empty($_POST['login']))  // Условие - если поле логин пустое
{
echo "Поле логин не заполненно"; // Выводим сообщение об ошибке
}
else // Иначе если поля не пустые
{
$pass = $_POST['pass']; // Присваеваем другой переменной значение из поля с паролем
$login = $_POST['login']; // Присваеваем переменной значение из поля с логином             
$query = "SELECT * FROM `users`";
$result = mysqli_query($link, $query) or die(mysql_error());

while($row = mysql_fetch_array($result))
{
echo "Номер: ".$row['login']."<br>\n";
echo "Имя: ".$row['password']."<br>\n";
echo "Фамилия: ".$row['email']."<br><hr>\n";
}

}

?>
