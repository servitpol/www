
<a href="index.php?page=1">Tours</a>
<a href="index.php?page=2">Comments</a>
<a href="index.php?page=3">Register</a>
<a href="index.php?page=4">Admin</a>
