﻿<?php
if(!isset($_COOKIE['name'])){
	setcookie('name', 'Johnnie Walker', time() + 30);
	setcookie('volume', '1', time() + 30);
} else {
	$_COOKIE['volume'] =  $_COOKIE['volume'] + 	1;
	setcookie('volume', $_COOKIE['volume'], time() + 30);
}
echo 'Name: '.$_COOKIE['name'].'</br>';
echo 'Volume: '.$_COOKIE['volume'].'</br>';
echo '</br>';
echo time();
echo '</br>';
?>
<a href="cookie1.php">Долить бухлишка</a>