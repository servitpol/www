<?php
session_start();
	echo 'id='.session_id().'</br>';
	$_SESSION['num'] = 10000;
	echo 'From file 1: '.$_SESSION['num'].'</br>';
?>
<a href="session2.php">Forward</a>