<?php 
	include_once ('functions.php'); /*_once означает что файл будет инклюдиться один раз, лучше пользоваться 
									ей чем простым include */
	addNumbers (53, 15); //литералы
	$n1 = 12;
	$n2 = 535;
	addNumbers ($n1, $n2);

	addNumbersColor(14, 22, "red");
	echo "</br>";

	$r = getSum(4, 202);
	echo $r;
?>