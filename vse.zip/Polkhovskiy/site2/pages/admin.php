<div class="col-lg-12 admin-content">
	<div class="row">
		<!-- Форма добавления стран -->
		<div class="admin-menu col-lg-6">
			<form action='index.php?page=4' method='POST' class="form-inline">
			<input type="text" name="country" class="form-control"/>
			<input type="submit" name="addcountry" class="btn btn-primary" value="Add country" />
			</form>
		</div>
		<!-- Форма добавления городов -->
		<div class="admin-menu col-lg-6">
			<form action='index.php?page=4' method='POST' class="form-inline">
			<select size="5" class="form-control" name="coid" required>
				<?php
				connect();
				$res = mysql_query('select * from countries');
				while($row = mysql_fetch_array($res, MYSQL_NUM)) {
					echo '<option value="'.$row[0].'">'.$row[1].'</option>';
				}
				mysql_free_result($res);
				?>
				</select>
			<input type="text" name="city" class="form-control"/>
			<input type="submit" name="addcity" class="btn btn-primary" value="Add city" />
			</form>
		</div>
	</div>
	<div class="row">
		<!-- Форма добавления отелей -->
		<div class="admin-menu col-lg-6">
			<form action='index.php?page=4' method='POST' class="form-inline">
				<div class='form-group'>
				<select class="form-control" name="coid" required>
				<?php
				connect();
				$res = mysql_query('select * from countries');
				while($row = mysql_fetch_array($res, MYSQL_NUM)) {
					echo '<option value="'.$row[0].'">'.$row[1].'</option>';
				}
				mysql_free_result($res);
				?>
				</select>
				<select class="form-control" name="ciid">
				<?php
				$res = mysql_query('select * from cities');
				while($row = mysql_fetch_array($res, MYSQL_NUM)) {
					echo '<option value="'.$row[0].'">'.$row[1].'</option>';
				}
				mysql_free_result($res);
				?>
				</select>
				<div class='form-group'>
					<input type="text" name="hotel" class="form-control" placeholder="Название отеля" required>
					<input type="number" name="cost" class="form-control" placeholder="Стоимость проживания в $">
					<input type="number" name="stars" class="form-control" placeholder="Кол-во звезд">
					<textarea name="info" class="form-control" placeholder="Комментарий к отелю"></textarea>
				</div>
				<input type="submit" name="addhotel" class="btn btn-primary" value="Add hotel"/>
				
				</div>
			</form>
		</div>
		<!-- Форма добавления еще чего-то-->
		<div class="admin-menu col-lg-6">
		<form action='index.php?page=4' method='POST' class="form-inline" enctype="multipart/form-data">
			<div class='form-group'>
			<select class="form-control" name="hid">
			<?php
			connect();
			$res = mysql_query('select * from hotels');
			while($row = mysql_fetch_array($res, MYSQL_ASSOC)){
				echo '<option value="'.$row['id'].'">'.$row['hotel'].'</option>';
			}
			mysql_free_result($res);
			?>
			</select>
			<input type="file" name="hotimg[]" multiple accept="image/*">
			<input type="submit" name="addimg" class="btn btn-primary" value="Add img" />
			</div>
		</form>		
		</div>
	</div>
</div>

<?php
if(isset($_POST['addhotel'])){  //добавление отеля

	$countryid = $_POST['coid'];
	$cityid = $_POST['ciid'];
	$hotel = trim(htmlspecialchars($_POST['hotel']));
	$info = trim(htmlspecialchars($_POST['info']));
	$stars = $_POST['stars'];
	$cost = $_POST['cost'];
	$ins = 'insert into hotels (hotel, countryid, cityid, cost, stars, info) values 
	("'.$hotel.'", '.$countryid.', '.$cityid.', '.$cost.', '.$stars.', "'.$info.'")';
	connect();
	mysql_query($ins);
	
}

if(isset($_POST['addcountry'])) { 	//добавление страны

	$country = $_POST['country'];
	connect();
	mysql_query('insert into countries (country) values ("'.$country.'")');

}

if(isset($_POST['addcity'])) { 	//добавление страны

	$city = $_POST['city'];
	connect();
	mysql_query('insert into cities (city, countryid) values ("'.$city.'", '.$coid.')');

}

if(isset($_POST['addimg'])) { 	//добавление фото

	foreach($_FILES['hotimg']['name'] as $k => $v){
		if($_FILES['hotimg']['error'][$k] != 0) {
			continue;
		}
		if(move_uploaded_file($_FILES['hotimg']['tmp_name'][$k], 'images/'.$v))
		{
			$ins = 'insert into images (hotelid, imagepath) values ('.$_POST['hid'].', "images/'.$v.'")';
			connect();
			mysql_query($ins);
		}
	}



}

?>