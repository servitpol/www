<?php include_once('header.php'); ?>
<?php 
$fp = fopen('counter.txt', 'w');
session_start();
$login = ($_SESSION['login']);
$_SESSION['project'] = ($_GET['project']);
$proj = $_SESSION['project'];
if($login != NULL) {
	include_once('connect.php');
	
} else {
	header("Location: login.php"); exit;
}	
?>
<header class="col-lg-12">
<div class="col-lg-9">Сервис проверки индексации ссылок</div>
<div class="col-lg-3"><?php echo ' '.$login.' '; ?><span class="glyphicon glyphicon-user"></span><a href="?exits"> Выход </a><a href="cheks.php?project=<?php echo $_GET['project']; ?>">| Назад</a></div>
</header>
<?php 
if (isset($_GET['exits'])) {
     session_destroy();
	 header("Location: login.php"); exit;
}
?>
<div class="content col-lg-12">
<table class="table col-lg-9" style="max-width: 800px; margin: 20px;">
	<thead>
  
		<th>URL донора</th>
		<th>ТИЦ</th>
		<th>Текст</th>
		<th>Цена</th>
		<th>Дата</th>
		<th>YAP</th>
		<th>YAL</th>
		<th>GP</th>
		<th>GL</th>
    
	</thead>
	<tbody>
<?php 
$db_table = "cheks";
$q = mysql_query("SELECT (content) FROM ".$db_table." where (id) IN ('".$_GET['id']."')",$db) or die(mysql_error()); //в $a записывается запрос к бд
$f = mysql_fetch_assoc($q);
$history = explode(";", $f['content']);
		echo '<tr>';
	foreach($history as $key){
		echo $key;
	}
	/*echo $history[$i];
	echo $history[$i++];
	echo $history[$i++];
	echo $history[$i++];
	echo $history[$i++];
	echo $history[$i++];
	echo $history[$i++];
	echo $history[$i++];
	echo $history[$i++];*/



?>
	
	</tbody>
</table>

</div>
<?php include_once('footer.php'); ?>