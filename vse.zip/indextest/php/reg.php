﻿<?php 
if (!preg_match("/^(http|https):\/\/([A-Z0-9][A-Z0-9_-]*(?:.[A-Z0-9][A-Z0-9_-]*)+):?(d+)?\/?/Diu", $_POST['name'], $matches))
{
echo 'Uncorrect url';
}
else
{
$_POST['name'] = str_ireplace('http://', '', $_POST['name']);	
$_POST['name'] = str_ireplace('https://', '', $_POST['name']);
include_once '../php/megaindex.php';
$key = '4796663281ced5672d6d6f899147eb63'; // Ваш API ключ !!!
$mi = new MegaIndex($key);		
$maxbacklinks = $_POST['maxbacklinks'];
$param = array('domain' => $_POST['name'], 'count' => $maxbacklinks, 'link_per_domain' => 1);
$array = $mi->get('outlinks', $param);
$result = $array;
for($i = 0;$i < (count($result, COUNT_RECURSIVE) - $maxbacklinks - count($result)) / 17; ++$i) {
echo '<tr><td>'.$i.'</td><td>'.'<a>'.'http://'.$result['data'][$i]['domain_to'].'</a>'.'</td></tr>'.'</br>';
}
//var_dump($result);
}
	
?>