<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/style.css" rel="stylesheet">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Тестовый сайт №1 по курсу PHP</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <header class="container-fluid">
		<div class="row">
			<div class="header-title">Тестовый сайт №2 по курсу PHP</div>
		</div>
    </header>
    <div class="wrapper">
    	<div class="container">
  	        <div class="row">
		        <div class="sidebar col-lg-3">
            <?php include_once ('pages/menu.php'); ?>
			<?php include_once ('pages/functions.php'); ?>
            
            
            </div>         
		    <div class="content col-lg-9"> 
			<?php 
			if(isset($_GET['page']) && ($_GET['page'] == 1)){
				include_once ('pages/tours.php');
			} else if(isset($_GET['page']) && ($_GET['page'] == 2)){
				include_once ('pages/comments.php');
			} else if(isset($_GET['page']) && ($_GET['page'] == 3)){
				include_once ('pages/register.php');
			} else if(isset($_GET['page']) && ($_GET['page'] == 4)){
				include_once ('pages/admin.php');
			} else {
				include_once ('pages/default.php');
			}
			?>
            </div> <!-- col-lg-9 -->
    		</div><!-- row -->
    	</div><!-- container-->
    </div><!-- wrapper-->

    <footer>
		<div class="container">
			<div class="footer-content">
				<p>footer и какой-то текст в нем</p>
			</div>
		</div>
    </footer>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>