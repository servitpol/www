<?php 
function addNewTz)($category, $name, $texttz) {
	$db_host = "servitsj.beget.tech"; //соединение с apache
    $db_user = "servitsj_test"; // Логин БД
    $db_password = "622756"; // Пароль БД

    $db = mysql_connect($db_host, $db_user, $db_password) OR DIE("Не могу создать соединение "); // Подключение к базе данных
	
    mysql_select_db("servitsj_test",$db); // Выборка базы
    mysql_query("SET NAMES 'utf8'",$db); // Установка кодировки соединения
	
	$result = mysql_query ("INSERT INTO tz (category, name, texttz) VALUES ('$category', '$name', '$texttz'");
}




?>